// Cabecera.js
// Información de la asignatura
// Version 1.0. 28/10/2021. Juan Rodríguez de la Fuente. Universidad de Oviedo

var cabecera = new Object();
cabecera.nombre = "Software y Estándares para la Web.";
cabecera.titulacion = "Ingeniería Informática del Software";
cabecera.centro = "Escuela de Ingeniería informática de Oviedo";
cabecera.universidad = "Universidad de Oviedo";
cabecera.curso = "2021/2022";
cabecera.estudiante = "Juan Rodríguez de la Fuente";
cabecera.email = "uo271773@uniovi.es";