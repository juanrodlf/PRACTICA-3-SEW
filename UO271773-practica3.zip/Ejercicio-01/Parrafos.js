// Parrafos.js
// Version 1.0. 28/10/2021. Juan Rodríguez de la Fuente. Universidad de Oviedo

document.write("<p>");
document.write(cabecera.curso);
document.write("</p>");
document.write("<p>");
document.write(cabecera.estudiante);
document.write("</p>");
document.write("<p>");
document.write(cabecera.email);
document.write("</p>");