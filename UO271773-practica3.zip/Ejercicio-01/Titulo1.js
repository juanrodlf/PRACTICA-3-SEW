// Titulo1.js
// Información de la asignatura
// Version 1.0. 28/10/2021. Juan Rodríguez de la Fuente. Universidad de Oviedo

document.write("<h1>");
document.write(cabecera.nombre);
document.write("</h1>");