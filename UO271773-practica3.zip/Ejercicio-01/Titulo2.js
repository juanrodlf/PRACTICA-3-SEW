// Titulo2.js
// Version 1.0. 28/10/2021. Juan Rodríguez de la Fuente. Universidad de Oviedo

document.write("<h2>");
document.write(cabecera.titulacion);
document.write("</h2>");