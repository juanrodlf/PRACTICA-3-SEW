// Titulo2.js
// Version 1.0. 28/10/2021. Juan Rodríguez de la Fuente. Universidad de Oviedo

document.write("<h4>");
document.write(cabecera.universidad);
document.write("</h4>");