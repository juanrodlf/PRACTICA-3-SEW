/* MasInfoNavegador.js */
// Version 1.0 08/11/2021 
document.write("Versión: ");
document.write(infoNavegador.version);
document.write(" - Plataforma: ");
document.write(infoNavegador.plataforma);
document.write(" - Vendedor: ");
document.write(infoNavegador.vendedor);
document.write(" - Agente: ");
document.write(infoNavegador.agente);
document.write(" - Java Activo: ");
document.write(infoNavegador.javaActivo);