/* NombreNavegador.js */
// Version 1.0 08/11/2021 
document.write(infoNavegador.nombre);