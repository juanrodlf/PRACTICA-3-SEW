Al validar CSS me da dos advertencias que no logré encontrar lo que significaban,
y por tanto no pude quitarlas:
-Redefinición de grid-row-start
-Redefinición de grid-row-end

La calculadora es igual que la del anterior ejercicio porque a la calculadora
base le añadí unas funciones que me parecieron suficientes para considerarla 
matemática avanzada.